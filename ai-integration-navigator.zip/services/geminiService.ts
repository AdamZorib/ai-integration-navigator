
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

// IMPORTANT: The API key is expected to be set in the environment.
// For a React app built with Vite, it would be `import.meta.env.VITE_GEMINI_API_KEY`.
// For Create React App, it would be `process.env.REACT_APP_GEMINI_API_KEY`.
// The instructions explicitly state `process.env.API_KEY`. This code assumes
// the build environment makes `process.env.API_KEY` available to the client-side bundle.
const API_KEY = process.env.API_KEY;

let ai: GoogleGenAI | null = null;

if (API_KEY) {
  ai = new GoogleGenAI({ apiKey: API_KEY });
} else {
  console.error(
    "Gemini API Key not found. Please set the API_KEY environment variable." +
    " For client-side React, this usually means prefixing with REACT_APP_ or VITE_ and ensuring your build process includes it."
  );
}

const MODEL_NAME = "gemini-2.5-flash-preview-04-17";

export const generateGeminiResponse = async (prompt: string): Promise<string> => {
  if (!ai) {
    throw new Error("Gemini AI client is not initialized. Check API Key configuration.");
  }

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      // config: {
      //   // Add thinkingConfig: { thinkingBudget: 0 } here if low latency is critical
      //   // and the model supports it (gemini-2.5-flash-preview-04-17 does).
      //   // For these general suggestions, default thinking is fine.
      // },
    });
    
    // Directly access the text property as per Gemini API guidance
    const text = response.text;
    if (typeof text !== 'string') {
        console.error("Unexpected response format from Gemini API:", response);
        throw new Error("Received an unexpected response format from the AI.");
    }
    return text;

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof Error) {
        // Check for specific error messages that might indicate API key issues
        if (error.message.includes("API key not valid")) {
            throw new Error("Invalid Gemini API Key. Please check your configuration.");
        }
        if (error.message.includes("quota")) {
            throw new Error("You have exceeded your Gemini API quota. Please check your usage and limits.");
        }
    }
    throw new Error("An error occurred while communicating with the AI. Please try again later.");
  }
};
