
import React from 'react';

interface HeaderProps {
  title: string;
  subtitle?: string;
}

const Header: React.FC<HeaderProps> = ({ title, subtitle }) => {
  return (
    <header className="text-center mb-10 sm:mb-16 w-full">
      <h1 className="text-4xl sm:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 via-indigo-500 to-purple-600 mb-2">
        {title}
      </h1>
      {subtitle && <p className="text-lg sm:text-xl text-gray-600">{subtitle}</p>}
    </header>
  );
};

export default Header;
