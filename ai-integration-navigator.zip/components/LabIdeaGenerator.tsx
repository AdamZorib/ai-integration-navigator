
import React, { useState, useCallback } from 'react';
import { generateGeminiResponse } from '../services/geminiService';
import { BeakerIcon } from './Icons'; // Assuming BeakerIcon is appropriate for Lab

const LabIdeaGenerator: React.FC = () => {
  const [industry, setIndustry] = useState<string>('');
  const [problemArea, setProblemArea] = useState<string>('');
  const [idea, setIdea] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerateIdea = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    setIdea('');

    let prompt = `Brainstorm a concise and actionable AI pilot project idea. Describe the problem it addresses and a potential AI approach. Keep it brief (2-3 sentences) and suitable for initial experimentation.`;
    if (industry.trim() && problemArea.trim()) {
      prompt += ` Tailor the idea for the "${industry}" industry, focusing on solving a problem related to "${problemArea}".`;
    } else if (industry.trim()) {
      prompt += ` Tailor the idea for the "${industry}" industry.`;
    } else if (problemArea.trim()) {
      prompt += ` Focus on solving a problem related to "${problemArea}".`;
    }
    prompt += ` Ensure the response is formatted clearly.`;


    try {
      const result = await generateGeminiResponse(prompt);
      setIdea(result);
    } catch (err) {
      console.error("LabIdeaGenerator Error:", err);
      setError('Failed to generate AI pilot idea. Please ensure your API key is configured correctly and try again.');
    } finally {
      setIsLoading(false);
    }
  }, [industry, problemArea]);

  return (
    <div className="space-y-4">
      <h3 className="text-xl font-semibold text-green-700 flex items-center">
        <BeakerIcon className="w-6 h-6 mr-2 text-green-500" />
        AI Pilot Project Idea Generator
      </h3>
      <p className="text-sm text-gray-500">Optionally provide an industry or problem area to tailor the AI pilot project idea, or leave blank for a general suggestion.</p>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label htmlFor="industry" className="block text-sm font-medium text-gray-700 mb-1">
            Industry (Optional):
          </label>
          <input
            type="text"
            id="industry"
            value={industry}
            onChange={(e) => setIndustry(e.target.value)}
            placeholder="e.g., Healthcare, Finance, Retail"
            className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-shadow"
            disabled={isLoading}
          />
        </div>
        <div>
          <label htmlFor="problemArea" className="block text-sm font-medium text-gray-700 mb-1">
            Problem Area (Optional):
          </label>
          <input
            type="text"
            id="problemArea"
            value={problemArea}
            onChange={(e) => setProblemArea(e.target.value)}
            placeholder="e.g., Customer churn, supply chain inefficiency"
            className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-shadow"
            disabled={isLoading}
          />
        </div>
      </div>

      <button
        onClick={handleGenerateIdea}
        disabled={isLoading}
        className="w-full sm:w-auto bg-green-600 hover:bg-green-700 text-white font-semibold py-2.5 px-5 rounded-lg shadow-md hover:shadow-lg transition-colors duration-200 disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center"
      >
        {isLoading ? (
           <>
            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            Generating Idea...
          </>
        ) : (
          'Generate Pilot Idea'
        )}
      </button>

      {error && <p className="text-red-600 bg-red-50 p-3 rounded-md text-sm">{error}</p>}

      {idea && !error && (
        <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
          <h4 className="font-semibold text-green-700 mb-2">Generated AI Pilot Idea:</h4>
          <div className="prose prose-sm prose-green max-w-none" dangerouslySetInnerHTML={{ __html: idea.replace(/\n/g, '<br />') }}></div>
        </div>
      )}
    </div>
  );
};

export default LabIdeaGenerator;
