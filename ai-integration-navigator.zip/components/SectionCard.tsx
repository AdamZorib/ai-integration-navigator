
import React from 'react';

interface SectionCardProps {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}

const SectionCard: React.FC<SectionCardProps> = ({ title, icon, children }) => {
  return (
    <section className="bg-white shadow-2xl rounded-xl p-6 sm:p-8 w-full transform transition-all duration-300 hover:shadow-blue-200 hover:-translate-y-1">
      <div className="flex items-center mb-4 sm:mb-6">
        <div className="mr-4 p-2 bg-blue-100 rounded-full">{icon}</div>
        <h2 className="text-2xl sm:text-3xl font-semibold text-gray-700">{title}</h2>
      </div>
      <div className="text-gray-600 leading-relaxed prose max-w-none prose-indigo">
        {children}
      </div>
    </section>
  );
};

export default SectionCard;
