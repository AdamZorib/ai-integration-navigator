
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="w-full max-w-4xl text-center mt-12 sm:mt-16 py-8 border-t border-gray-200">
      <p className="text-sm text-gray-500">
        &copy; {new Date().getFullYear()} AI Integration Navigator. All rights reserved.
      </p>
      <p className="text-xs text-gray-400 mt-1">
        Inspired by the "Leadership, Lab, and Laundry" framework from 
        <a 
          href="https://www.oneusefulthing.org/p/making-ai-work-leadership-lab-and" 
          target="_blank" 
          rel="noopener noreferrer"
          className="text-blue-500 hover:text-blue-600 underline ml-1"
        >
          One Useful Thing
        </a>.
      </p>
    </footer>
  );
};

export default Footer;
